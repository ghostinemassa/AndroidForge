package com.monsterrabbit.editor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private var videoUri: Uri? = null
    private var audioUri: Uri? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private lateinit var status: TextView
    private lateinit var titleInput: EditText
    private lateinit var projectName: EditText
    private lateinit var root: LinearLayout

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            playVideo(uri)
            status.text = "Vídeo adicionado à edição"
            saveProject()
        }
    }
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            audioUri = uri
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            status.text = "Áudio selecionado: ${uri.lastPathSegment ?: "arquivo local"}"
            saveProject()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,16,24)
        window.navigationBarColor = android.graphics.Color.rgb(16,16,24)
        buildUi()
        loadProject()
        videoUri?.let { playVideo(it) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 14f, color: Int = 0xFFEDEDF5.toInt()): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(color) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setOnClickListener { action() }
    }
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(12))
            setBackgroundColor(0xFF101018.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = text("MONSTERRABBIT", 23f, 0xFFC084FC.toInt())
        brand.typeface = android.graphics.Typeface.DEFAULT_BOLD
        content.addView(brand)
        content.addView(text("Editor de vídeo • V1 • Sem paywall", 13f, 0xFF9CA3AF.toInt()))
        projectName = EditText(this).apply {
            hint = "Nome do projeto"; setTextColor(-1); setHintTextColor(0xFF8B8B9A.toInt())
            setSingleLine(true); setText("Meu projeto")
        }
        content.addView(projectName, LinearLayout.LayoutParams(-1, dp(52)))
        playerView = PlayerView(this).apply {
            useController = true
            setBackgroundColor(0xFF050507.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, dp(220))
        }
        val previewFrame = FrameLayout(this).apply {
            setBackgroundColor(0xFF050507.toInt())
            addView(playerView, FrameLayout.LayoutParams(-1, dp(220)))
        }
        overlay = text("", 22f, -1).apply {
            gravity = Gravity.CENTER
            setShadowLayer(8f, 2f, 2f, android.graphics.Color.BLACK)
        }
        previewFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        content.addView(previewFrame)
        content.addView(text("MÍDIA LOCAL", 12f, 0xFF22D3EE.toInt()).apply { setPadding(0, dp(14), 0, 0) })
        content.addView(button("＋ Importar vídeo do celular") { pickVideo.launch(arrayOf("video/*")) })
        content.addView(button("♫ Escolher áudio do celular") { pickAudio.launch(arrayOf("audio/*")) })
        content.addView(text("TEXTO E EFEITOS", 12f, 0xFF22D3EE.toInt()).apply { setPadding(0, dp(10), 0, 0) })
        titleInput = EditText(this).apply {
            hint = "Digite o texto para aparecer no vídeo"
            setTextColor(-1); setHintTextColor(0xFF8B8B9A.toInt())
            setSingleLine(false); minLines = 1; maxLines = 3
            setText("Meu vídeo")
        }
        content.addView(titleInput, LinearLayout.LayoutParams(-1, dp(56)))
        val effectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        effectRow.addView(button("Normal") { setTextEffect("normal") }, LinearLayout.LayoutParams(0, dp(52), 1f))
        effectRow.addView(button("Sombra") { setTextEffect("shadow") }, LinearLayout.LayoutParams(0, dp(52), 1f))
        effectRow.addView(button("Contorno") { setTextEffect("stroke") }, LinearLayout.LayoutParams(0, dp(52), 1f))
        content.addView(effectRow)
        content.addView(button("Aplicar texto à prévia") {
            overlay.text = titleInput.text.toString()
            setTextEffect(currentEffect)
            saveProject()
            status.text = "Texto aplicado à prévia. A exportação renderizada será adicionada numa próxima etapa."
        })
        content.addView(text("LINHA DO TEMPO", 12f, 0xFF22D3EE.toInt()).apply { setPadding(0, dp(12), 0, 0) })
        content.addView(text("VÍDEO  ━━━━━━━━━━━━━━━━━━━\nTEXTO  ─────── ${"●"} ─────────\nÁUDIO ────────────────", 13f, 0xFFD1D5DB.toInt()).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(0xFF1C1C29.toInt())
        })
        status = text("Pronto para editar.", 12f, 0xFF9CA3AF.toInt()).apply { setPadding(0, dp(8), 0, 0) }
        content.addView(status)
        content.addView(button("Salvar projeto no celular") { saveProject(); status.text = "Projeto salvo neste aplicativo." })
        content.addView(text("Os arquivos de mídia permanecem no seu aparelho. O app não exige conta nem internet.", 11f, 0xFF9CA3AF.toInt()).apply {
            setPadding(0, dp(10), 0, dp(10))
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private var currentEffect = "shadow"
    private fun setTextEffect(effect: String) {
        currentEffect = effect
        overlay.text = titleInput.text.toString()
        overlay.setShadowLayer(0f, 0f, 0f, 0)
        overlay.paint.style = android.graphics.Paint.Style.FILL
        when (effect) {
            "shadow" -> overlay.setShadowLayer(8f, 2f, 2f, android.graphics.Color.BLACK)
            "stroke" -> {
                overlay.paint.style = android.graphics.Paint.Style.STROKE
                overlay.paint.strokeWidth = dp(2).toFloat()
                overlay.setTextColor(0xFF22D3EE.toInt())
            }
            else -> { overlay.paint.style = android.graphics.Paint.Style.FILL; overlay.setTextColor(-1) }
        }
        if (effect != "stroke") overlay.setTextColor(-1)
        saveProject()
    }

    private fun playVideo(uri: Uri) {
        if (player == null) {
            player = ExoPlayer.Builder(this).build()
            playerView.player = player
        }
        player?.setMediaItem(MediaItem.fromUri(uri))
        player?.prepare()
        player?.playWhenReady = false
    }

    private fun saveProject() {
        if (!::projectName.isInitialized) return
        val data = JSONObject()
            .put("name", projectName.text.toString())
            .put("video", videoUri?.toString() ?: "")
            .put("audio", audioUri?.toString() ?: "")
            .put("text", if (::titleInput.isInitialized) titleInput.text.toString() else "")
            .put("effect", currentEffect)
        getSharedPreferences("project", MODE_PRIVATE).edit().putString("last_project", data.toString()).apply()
    }
    private fun loadProject() {
        val raw = getSharedPreferences("project", MODE_PRIVATE).getString("last_project", null) ?: return
        runCatching {
            val data = JSONObject(raw)
            projectName.setText(data.optString("name", "Meu projeto"))
            titleInput.setText(data.optString("text", "Meu vídeo"))
            videoUri = data.optString("video", "").takeIf { it.isNotBlank() }?.let(Uri::parse)
            audioUri = data.optString("audio", "").takeIf { it.isNotBlank() }?.let(Uri::parse)
            currentEffect = data.optString("effect", "shadow")
            overlay.text = titleInput.text
            setTextEffect(currentEffect)
        }
    }
    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
