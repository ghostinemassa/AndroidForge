# MonsterRabbit — Android project (V1 foundation)

MonsterRabbit is an offline-first Android video-editor foundation, with no subscriptions, account, or paywall.

## Included in this source version
- Native Android app shell and dark editor interface
- Import a local video through Android's document picker
- Video preview with playback controls (Media3)
- Choose a local audio file
- Text overlay preview with normal, shadow, and outline styles
- Simple visual timeline concept
- Saves the last project's name, media references, text, and effect locally
- No account and no runtime internet permission

## Important limitation
This is a **starter MVP, not a finished full video editor**. It does not yet render/export a final MP4 with text and audio mixed together; the text and timeline are currently an editing preview. That requires implementing and testing a media-render pipeline (Media3 Transformer plus overlay composition/audio mixing) on actual Android devices.

## Build
1. Install Android Studio (current stable) on a computer.
2. Open this folder as a project.
3. Allow Gradle to download the Android Gradle Plugin and Media3 dependencies. This build step requires internet on the computer; the installed app is designed to work offline.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android phone and test video/audio permissions and codec support.

Minimum Android: 8.0 (API 26). Target SDK: 35.

## Test checklist
- [ ] App launches and editor screen renders
- [ ] Select and preview a local video
- [ ] Select local audio
- [ ] Add text and test each visual style
- [ ] Close/reopen and check saved project state
- [ ] Test with large 4K videos and low-storage devices
- [ ] Implement and verify actual MP4 export before calling this a complete editor

## Next implementation milestone
1. Real multi-clip timeline and trim/split.
2. Audio track playback, volume and fade controls.
3. Rendered text overlays and audio mixing in exported MP4.
4. Export quality options (720p/1080p), progress and cancellation.
5. Project library and recovery after app restart.
